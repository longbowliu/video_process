#include <liveMedia.hh>
#include"v4l2_camera.h"
class H264FramedLiveSource : public FramedSource
{
 
public:
	static H264FramedLiveSource* createNew(UsageEnvironment& env, v4l2Camera  *cam_source);
	// redefined virtual functions
	virtual unsigned maxFrameSize() const;
	v4l2Camera * cam_source =NULL ;
 
protected:
 
	H264FramedLiveSource(UsageEnvironment& en,v4l2Camera * camv);
 
	 virtual ~H264FramedLiveSource();
 
private:
	virtual void doGetNextFrame();
	
 
protected:
	
	// static TestFromFile * pTest;
 
};