#include "H264FramedLiveSource.hh"

H264FramedLiveSource::H264FramedLiveSource(UsageEnvironment& env)
: FramedSource(env)
{
 
}
 
 
H264FramedLiveSource* H264FramedLiveSource::createNew(UsageEnvironment& env)
{
	H264FramedLiveSource* newSource = new H264FramedLiveSource(env);
	return newSource;
}
 
H264FramedLiveSource::~H264FramedLiveSource()
{
 
}
unsigned H264FramedLiveSource::maxFrameSize() const
{
	//printf("wangmaxframesize %d %s\n",__LINE__,__FUNCTION__);
	//这里返回本地h264帧数据的最大长度
	return 1024*120;
}
 
void H264FramedLiveSource::doGetNextFrame()
{
        //这里读取本地的帧数据，就是一个memcpy(fTo,XX,fMaxSize),要确保你的数据不丢失，即fMaxSize要大于等于本地帧缓存的大小，关键在于上面的maxFrameSize() 虚函数的实现
    //     fFrameSize = XXXgeth264Frame(fTo,  fMaxSize);
    //     printf("read dat befor %d %s fMaxSize %d ,fFrameSize %d  \n",__LINE__,__FUNCTION__,fMaxSize,fFrameSize);
		
	// if (fFrameSize == 0) {
	// 	handleClosure();
	// 	return;
	//   }
 
 
	  //设置时间戳
	  gettimeofday(&fPresentationTime, NULL);
 
	  // Inform the reader that he has data:
	  // To avoid possible infinite recursion, we need to return to the event loop to do this:
	  nextTask() = envir().taskScheduler().scheduleDelayedTask(0,
					(TaskFunc*)FramedSource::afterGetting, this);
 
	// }
	
	return;
}